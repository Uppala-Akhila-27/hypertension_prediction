import numpy as np
from flask import Flask, request, render_template
import pickle
app = Flask(__name__)
model = pickle.load(open('random.pkl', 'rb'))
from flask import Markup

@app.route('/')
def home():
    
    return render_template('home.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    x_test = [float(x) for x in request.form.values()]
    
    x_test = np.array(x_test).reshape(1,8)
    prediction = model.predict(x_test)
    
    output=prediction[0]
    #if output>3:
    pred=Markup("The hypertension risk score is: "+str(int(output)))
    #else:
        #pred=Markup("The churn risk score is: "+str(int(output))+"<br><h1 align='center' style='color: green'>No need to worry!")
    return render_template('home.html',output=pred)
    




if __name__ == "__main__":
    app.run(debug=True)
